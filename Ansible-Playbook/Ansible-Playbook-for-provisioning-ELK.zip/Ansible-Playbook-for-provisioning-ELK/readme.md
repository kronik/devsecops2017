# E:L:K Stack Ansible Playbook

---

### To run playbook

- Please do necessary changes to the variables and inventory files and run the below command.

```
ansible-playbook main.yml -i inventory.ini --user=madhuakula --ask-sudo-pass -vvv
```

