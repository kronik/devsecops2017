#ifndef _IEEEFP_H_
#define _IEEEFP_H_

#include <crtdefs.h>
#include <math.h>
#include <ansidecl.h>

#endif /* _IEEE_FP_H_ */

